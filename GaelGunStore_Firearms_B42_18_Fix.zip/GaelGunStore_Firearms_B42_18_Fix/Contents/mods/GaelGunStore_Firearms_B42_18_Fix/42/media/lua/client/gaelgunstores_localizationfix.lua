local ACRONYMS = {
    ["ak"] = "AK",
    ["akm"] = "AKM",
    ["ak74"] = "AK-74",
    ["ar"] = "AR",
    ["ar15"] = "AR-15",
    ["hk"] = "HK",
    ["lvoa"] = "LVOA",
    ["lmt"] = "LMT",
    ["pk"] = "PK",
    ["m4"] = "M4",
    ["m14"] = "M14",
    ["m16"] = "M16",
    ["mp"] = "MP",
    ["rpk"] = "RPK",
    ["svd"] = "SVD",
    ["fn"] = "FN",
    ["g3"] = "G3",
    ["g36"] = "G36",
    ["usp"] = "USP",
    ["acr"] = "ACR",
    ["acp"] = "ACP",
    ["lr"] = "LR",
    ["fmj"] = "FMJ",
    ["hp"] = "HP",
    ["ui"] = "UI",
    ["at"] = "AT",
    ["12ga"] = "12GA",
    ["9mm"] = "9mm",
    ["45acp"] = ".45 ACP",
    ["50cal"] = ".50 Cal",
    ["30"] = "30",
    ["06"] = "06",
}

local REPLACEMENTS = {
    ["hg"] = "Handguard",
    ["sopmod"] = "SOPMOD",
    ["mag"] = "Magazine",
    ["clip"] = "Clip",
    ["drum"] = "Drum Magazine",
    ["carton"] = "Carton",
    ["bullets"] = "Bullets",
    ["box"] = "Box",
    ["stock"] = "Stock",
}

local function splitCamelCase(str)
    str = str:gsub("(%l)(%u)", "%1 %2")
    str = str:gsub("(%a)(%d)", "%1 %2")
    str = str:gsub("(%d)(%a)", "%1 %2")
    return str
end

local function cleanWord(word)
    local lower = string.lower(word)

    if ACRONYMS[lower] then
        return ACRONYMS[lower]
    end

    if REPLACEMENTS[lower] then
        return REPLACEMENTS[lower]
    end
    return string.upper(word:sub(1,1)) .. string.lower(word:sub(2))
end

local function prettify(raw)
    if not raw then return raw end
    raw = tostring(raw)
    raw = raw:gsub("^Base%.", "")
    raw = raw:gsub("_", " ")
    raw = raw:gsub("%-", " ")
    raw = splitCamelCase(raw)

    local words = {}

    for word in raw:gmatch("%S+") do
        table.insert(words, cleanWord(word))
    end

    local result = table.concat(words, " ")

    result = result:gsub("30 06", "30-06")
    result = result:gsub("22 LR", ".22 LR")
    result = result:gsub("308", ".308")
    result = result:gsub("357", ".357")
    result = result:gsub("44 ACP", ".44 ACP")
    result = result:gsub("45 ACP", ".45 ACP")
    result = result:gsub("50 Cal", ".50 Cal")

    return result
end

local function needsFix(displayName, fullType)
    if not displayName then return true end

    displayName = tostring(displayName)

    if displayName == "" then
        return true
    end

    if displayName == fullType then
        return true
    end

    if displayName:find("^Base%.") then
        return true
    end

    if displayName:find("_") then
        return true
    end

    if displayName:match("^[A-Za-z0-9_]+$") then
        return true
    end

    return false
end

local function applyFixes()
    local manager = ScriptManager.instance
    if not manager then return end

    local items = manager:getAllItems()
    if not items then return end

    local fixedCount = 0

    for i = 0, items:size() - 1 do
        local item = items:get(i)

        if item then
            local fullType = item:getFullName()
            local displayName = item:getDisplayName()
            local internalName = item:getName()

            if needsFix(displayName, fullType) then
                local fixed = prettify(internalName)

                if fixed and fixed ~= "" then
                    item:setDisplayName(fixed)
                    fixedCount = fixedCount + 1
                end
            end
        end
    end

    print("GaelGunstore 42.18 Fix.. fixed" .. tostring(fixedCount) .. " items.")
end

Events.OnGameBoot.Add(applyFixes)
