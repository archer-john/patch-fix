local DEFAULT_PART_CONDITION_MAX = 100

local function ggs_fix_logDebug(message)
    if GGSWeaponUpgrades and GGSWeaponUpgrades.Debug then
        print("[GGS B42Fix] " .. tostring(message))
    end
end

local function ggs_fix_getSandboxBoolean(key, defaultValue)
    local root = SandboxVars or nil
    if not root then return defaultValue end

    local value = nil
    if root.GGSGS then value = root.GGSGS[key] end
    if value == nil and root.GGS then value = root.GGS[key] end
    if value == nil then return defaultValue end

    if type(value) == "boolean" then return value end
    if type(value) == "number" then return value ~= 0 end
    if type(value) == "string" then
        local lower = value:lower()
        return lower == "true" or lower == "1" or lower == "yes"
    end
    return defaultValue
end

local function ggs_fix_clamp(value, minValue, maxValue)
    if value < minValue then return minValue end
    if value > maxValue then return maxValue end
    return value
end

local function ggs_fix_isWeaponPartItem(item)
    if not item then return false end
    return instanceof(item, "WeaponPart")
end

local function ggs_fix_shouldForceMaxPartCondition()
    return ggs_fix_getSandboxBoolean("weaponpart_loot_max_condition", true)
end

local function ggs_fix_shouldRandomizePartCondition()
    if ggs_fix_shouldForceMaxPartCondition() then return false end
    return ggs_fix_getSandboxBoolean("weaponpart_random_condition", false)
end

local function ggs_fix_setPartConditionPolicy(part, forceMax)
    if not ggs_fix_isWeaponPartItem(part) then return end

    local maxCondition = part.getConditionMax and part:getConditionMax() or 0
    if maxCondition <= 0 and part.setConditionMax then
        maxCondition = DEFAULT_PART_CONDITION_MAX
        part:setConditionMax(maxCondition)
    end
    if maxCondition <= 0 then return end

    local condition = part.getCondition and part:getCondition() or maxCondition
    if condition <= 0 then condition = maxCondition end
    condition = ggs_fix_clamp(condition, 0, maxCondition)

    if forceMax then condition = maxCondition end

    if part.setCondition then part:setCondition(condition) end
end

local function ggs_fix_applyRandomPartCondition(part)
    if not ggs_fix_isWeaponPartItem(part) then return end
    if not ggs_fix_shouldRandomizePartCondition() then return end

    local modData = part.getModData and part:getModData() or nil
    if modData and modData.GGS_RandomConditionDone then return end

    local maxCondition = part.getConditionMax and part:getConditionMax() or 0
    if maxCondition <= 1 then
        if modData then modData.GGS_RandomConditionDone = true end
        return
    end

    if part.setCondition then part:setCondition(ZombRand(maxCondition) + 1) end
    if modData then modData.GGS_RandomConditionDone = true end
end

local function ggs_fix_applyWeaponPartConditionPolicy(weapon, forceMax)
    if not weapon or not weapon.getAllWeaponParts then return end
    local parts = weapon:getAllWeaponParts()
    if not parts then return end
    for i = 0, parts:size() - 1 do
        ggs_fix_setPartConditionPolicy(parts:get(i), forceMax)
    end
end

local function ggs_fix_applyRandomWeaponPartCondition(weapon)
    if not weapon or not weapon.getAllWeaponParts then return end
    if not ggs_fix_shouldRandomizePartCondition() then return end
    local parts = weapon:getAllWeaponParts()
    if not parts then return end
    for i = 0, parts:size() - 1 do
        ggs_fix_applyRandomPartCondition(parts:get(i))
    end
end

local function ggs_fix_applyRandomWeaponCondition(weapon)
    if not weapon or not instanceof(weapon, "HandWeapon") then return end
    if not weapon.isRanged or not weapon:isRanged() then return end
    if not ggs_fix_getSandboxBoolean("weapon_random_condition", false) then return end

    local modData = weapon:getModData()
    if modData.GGS_RandomConditionDone then return end

    local maxCondition = weapon:getConditionMax() or 0
    if maxCondition <= 1 then
        modData.GGS_RandomConditionDone = true
        return
    end

    weapon:setCondition(ZombRand(maxCondition) + 1)
    modData.GGS_RandomConditionDone = true
end

local function applyToContainer_B42Fix(roomName, containerType, itemPicker)
    if not itemPicker then return end

    local itemContainer = nil
    local ok, result = pcall(function() return itemPicker:getContainer() end)
    if ok and result then
        itemContainer = result
    else
        itemContainer = itemPicker
    end

    local items = nil
    local ok2, result2 = pcall(function() return itemContainer:getItems() end)
    if ok2 and result2 then
        items = result2
    else
        return
    end

    local forceMaxParts = ggs_fix_shouldForceMaxPartCondition()

    for i = 0, items:size() - 1 do
        local item = items:get(i)
        if item and instanceof(item, "HandWeapon") then
            ggs_fix_applyRandomWeaponCondition(item)
            if GGSWeaponUpgrades and GGSWeaponUpgrades.ApplyToWeapon then
                local weaponType = item.getFullType and item:getFullType() or "unknown"
                ggs_fix_logDebug(("B42Fix OnFillContainer %s/%s contiene %s"):format(
                    tostring(roomName), tostring(containerType), weaponType))
                GGSWeaponUpgrades.ApplyToWeapon(item)
            end
            ggs_fix_applyWeaponPartConditionPolicy(item, forceMaxParts)
            ggs_fix_applyRandomWeaponPartCondition(item)
        elseif ggs_fix_isWeaponPartItem(item) then
            ggs_fix_setPartConditionPolicy(item, forceMaxParts)
            ggs_fix_applyRandomPartCondition(item)
        end
    end
end

if Events and Events.OnFillContainer then
    Events.OnFillContainer.Add(applyToContainer_B42Fix)
    ggs_fix_logDebug("gaelgunstore b42.18 fix.. fixed applytocontainer")
end
